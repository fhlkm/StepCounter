package com.example.sensorfunctiontest.test;

import android.test.AndroidTestCase;

public class SendAudoTest extends AndroidTestCase{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	

}
