package com.example.constant;

public interface AcousticAction {
	
	/**
	 * We are prepaing to calculate it
	 *  after recording finishRecording will be implemented
	 * @param recordAcousticData
	 */
	public abstract void finishcRecording(short[] recordAcousticData);

}
