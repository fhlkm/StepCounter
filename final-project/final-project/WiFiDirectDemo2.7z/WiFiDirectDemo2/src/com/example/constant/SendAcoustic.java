package com.example.constant;

public interface SendAcoustic {
//public abstract void sendDistance(int distance);// the distance that will be sent to its partner
}
